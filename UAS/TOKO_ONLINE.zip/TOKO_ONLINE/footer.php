<div class="container-fluid py-5 content-subscribe text-light">
    <div class="container">
        <h5 class="text-center mb-4">Temui Kami</h5>
        <div class="row justify-content-center">
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                   <a href="#"><i class="fab fa-facebook fs-4"></i></a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                   <a href="#"><i class="fab fa-instagram fs-4"></i></a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                   <a href="#"><i class="fab fa-twitter fs-4"></i></a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                   <a href="#"><i class="fab fa-youtube fs-4"></i></a>
            </div>
            <div class="col-sm-1 d-flex justify-content-center mb-2">
                   <a href="https://wa.me/6285801842533?text=Halo,%20saya%20ingin%20bertanya%20tentang%20produk%20Anda." target="_blank"><i class="fab fa-whatsapp fs-4"></i></a>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid py-3 bg-dark text-light">
    <div class="container d-flex justify-content-between">
        <label>&copy;2025 Ahmad Andre</label>
        <label>Created by Ahmad Andre</label>
    </div>
</div>